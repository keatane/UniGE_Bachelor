Membri - Gruppo 1 Threaddo:
Gabriele Dellepere	- S4944557
Kevin Cattaneo	- S4944382

Note:
Laboratorio verificato a runtime con RV-Predict e JavaPathFinder. Nessun errore rilevato.
Ammettiamo dei NullException e IllegalMonitorException, come già segnalato dal vivo (e confermato), che però non sono fatali.