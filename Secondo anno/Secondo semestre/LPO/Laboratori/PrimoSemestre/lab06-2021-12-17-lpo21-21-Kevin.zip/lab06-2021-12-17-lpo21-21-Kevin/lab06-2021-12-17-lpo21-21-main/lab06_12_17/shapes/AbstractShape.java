package lab06_12_17.shapes;

public abstract class AbstractShape implements Shape {

	private final Point center = new PointClass();

	protected static final double defaultSize = 1;

	protected static double requirePositive(double size) {
	    // to be completed
	    if(size < 0)
	    	throw new IllegalStateException();
	    return size;
	}

	protected AbstractShape(Point center) {
	    // to be completed
	    this.center.move(center.getX(),center.getY());
	}

	protected AbstractShape() {
	}

	@Override
	public void move(double dx, double dy) {
	    // to be completed
	    center.move(dx,dy);
	}

	@Override
	public Point getCenter() {
	    // to be completed
	    return center;
	}

}
