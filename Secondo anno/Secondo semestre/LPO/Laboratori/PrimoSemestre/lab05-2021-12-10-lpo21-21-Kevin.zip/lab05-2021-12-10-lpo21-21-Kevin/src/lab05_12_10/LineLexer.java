package lab05_12_10;

import java.util.NoSuchElementException;
import java.util.regex.*;

public class LineLexer implements Lexer {
	private final Matcher matcher;
	private MatchResult result; // risultato dell'ultimo match che ha avuto successo; definito solo se il metodo 'reset()' non è stato chiamato

	private MatchResult getResult() {
		if (this.result == null)
			throw new IllegalStateException();
		return this.result;
	}

	// crea un matcher con il pattern ottenuto compilando 'regEx' e la sequenza di input uguale a 'line'
	private LineLexer(String line, String regEx) {
	    // completare
	    Pattern pt = Pattern.compile(regEx);
	    matcher = pt.matcher(line);
	}

	// crea un matcher con il pattern ottenuto compilando 'regEx' e la sequenza di input uguale alla stringa vuota
	private LineLexer(String regEx) {
	    // completare
	    Pattern pt = Pattern.compile(regEx);
	    matcher = pt.matcher("");
	}

	// factory method che usa il costruttore LineLexer(String line, String regEx) 
	public static LineLexer withLineRegex(String line, String regEx) {
	    // completare
	    LineLexer l = new LineLexer(line, regEx);
	    return l;
	}

	// factory method che usa il costruttore LineLexer(String regEx)
	public static LineLexer withRegex(String regEx) {
	    // completare
	    LineLexer l = new LineLexer(regEx);
	    return l;
	}

	public void next() {
	    // completare
	    this.result = null;
	    if(!this.hasNext()) throw new NoSuchElementException();
	    if(!this.matcher.find()) throw new RuntimeException();
	    result = matcher.toMatchResult();
	    this.matcher.region(this.getResult().end(), this.matcher.regionEnd());
	}

	public String lexemeString() {
	    // completare
	    return this.getResult().group();
	    
	}

	public int lexemeGroup() {
	    // completare
	    for(int i=1; i <= this.getResult().groupCount(); ++i){
	    	if(this.getResult().group(i) != null) return i; 
	    }
	    return -1;
	}

	public boolean hasNext() {
	    // completare
	    return this.matcher.regionStart() < this.matcher.regionEnd();
	}

	public void reset(String line) {
	    // completare
	    this.result = null;
	    matcher.reset(line);
	}
}
