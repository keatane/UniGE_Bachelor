let rec ord_insert e = function h::t as ls-> if(e = h) then h::t else if(e < h) then [e]@(h::t) else h::ord_insert e t | _ -> e::[];; 

(* is equivalent to return just [e] *)

(* altra notazione
let rec ord_insert e = function h::t as ls-> if(e = h) then h::t else if(e < h) then e::ls else h::ord_insert e t | _ -> e::[];; 


ord_insert 0 [1;2;4;5];;
ord_insert 3 [1;2;4;5];;
ord_insert 7 [1;2;4;5];;
ord_insert 2 [1;2;4;5];;
