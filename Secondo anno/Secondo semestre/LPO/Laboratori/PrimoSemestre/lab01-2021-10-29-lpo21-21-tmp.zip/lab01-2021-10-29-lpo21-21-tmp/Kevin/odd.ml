let rec odd = function h::i::t -> h::odd t | h::t -> h::[] | _ -> [];; (* according to DGabriele *)

(* Altra notazione
let rec odd = function h::_::t -> h::odd t | l -> l;;
l -> l ingloba la lista con un solo elemento e la lista vuota, restituisce lo stesso
*)
