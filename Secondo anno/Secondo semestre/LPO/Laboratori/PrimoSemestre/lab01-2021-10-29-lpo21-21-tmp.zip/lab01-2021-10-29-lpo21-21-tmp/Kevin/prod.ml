let rec prod = function h::t -> h*prod t | _ -> 1;;
prod [2;3;4];;
prod [4;5;6];;
prod [false, false, true];; -- errore (correttamente)

// '_' inteso come EOL
// specificare []->0 solleva un warning come "_->1" non utilizzato
// Inoltre EOL lo identifica come lista vuota [], quindi prod[2;3;4] restituisce zero in let rec prod = function h::t -> h*prod t | _ -> 1;;
