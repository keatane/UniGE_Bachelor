(* member function auxiliary *)

let rec member e = function h::t -> if(e = h) then true else member e t | _->false ;;
member 3 [2;3;4];;
member 5 [2;3;4];;

let insert e = function ls -> if(member e ls) then ls else ls@[e];;
(* la concatenazione permette di inserire l'elemento in fondo *)
insert 0 [2;3;4];;
insert 3 [2;3;4];;

(* nota non effettuando un controllo sugli errori, posso ovviare al patter matching mediante un semplice if then else *)
(* Altra notazione:

let insert e = function h::t -> h::if(e = h) then t else insert e t;;

*)
