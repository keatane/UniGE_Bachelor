let rec member e = function h::t -> if(e = h) then true else member e t | _->false ;;
member 3 [2;3;4];;
member 5 [2;3;4];;

// '_' è da intendere sempre l'EOL
(* Altra notazione: pongo in OR, se e=h falso allora esamina e restituisce member
let rec member e = function h::t -> e = h || member e t 
| _->false ;;
*)
