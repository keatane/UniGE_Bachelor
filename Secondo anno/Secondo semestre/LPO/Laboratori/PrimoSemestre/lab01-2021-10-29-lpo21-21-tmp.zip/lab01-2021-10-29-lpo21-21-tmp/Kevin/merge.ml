let rec ord_insert e = function h::t -> if(e = h) then h::t else if(e < h) then [e]@(h::t) else h::ord_insert e t | _ -> e::[];; 

(* auxiliary function to take the tail of the list *)
(* let taketail = function j::k -> k | _ -> [];;  taketail diventa inutile con questa soluzione *)

let rec merge = function (ls, h::t) -> merge (ord_insert h ls, t) | (ls,_) -> ls;;

(* la funzione prende una coppia *)

merge ([1;3;5],[2;4;6]);;
merge ([1;2;3],[4;5]);;
merge ([3],[1;2;4;5]);; 


