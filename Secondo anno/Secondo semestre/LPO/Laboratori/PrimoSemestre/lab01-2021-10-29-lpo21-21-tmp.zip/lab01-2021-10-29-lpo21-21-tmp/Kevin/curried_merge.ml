let rec ord_insert e = function h::t -> if(e = h) then h::t else if(e < h) then [e]@(h::t) else h::ord_insert e t | _ -> e::[];; 

(* auxiliary function to take tail of the list *)
let taketail = function j::k -> k | _ -> [];;

let rec curried_merge = function ls ->  function h::t -> curried_merge ls (taketail (ord_insert h ls)) | _ -> ls;;

curried_merge [1;3;5] [2;4;6];;
curried_merge [1;2;3] [4;5];;
curried_merge [3] [1;2;4;5];;

(* note: infinity loop is created *)

(* altra notazione: prende due argomenti (e non una sola coppia come per la merge uncurried)
let rec curried_merge l1 l2 = match l1, l2 with
  hd1::tl1 as l1, (hd2::tl2 as l2) ->
    if hd1 < hd2 then gd1::curried_merge tl1,l2 else
      if hd1=hd2 then hdi::curried_merge tl1,tl2 else hd2::curried_merge l1,tl2
  | [], l -> l
  | l,_ -> l
 *)
