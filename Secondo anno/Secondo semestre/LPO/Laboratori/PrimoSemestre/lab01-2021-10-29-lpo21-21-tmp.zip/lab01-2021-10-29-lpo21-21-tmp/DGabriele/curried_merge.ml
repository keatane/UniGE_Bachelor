let rec curried_merge x y = match x, y with a::b,c::d -> 
	if a < c then a::curried_merge b (c::d) else if a > c then c::curried_merge (a::b) d else a::curried_merge b d |
	[],c::d -> c::curried_merge [] d |
	a::b,[] -> a::curried_merge b [] |
	_ -> [];;
  
  (* in questo caso mi sono avvalso di un piccolo cheat:
  Utilizzando la forma lunga del pattern matching converto i parametri in una tupla e poi effettuo
  il matching su quella, utilizzando per il merge lo stesso algoritmo.
  (non ho trovato modo di fare contemporaneamente matching di due parametri separati e per più casi)
  La funzione rimane curried, perché nulla mi vieta di passare prima solo un parametro, definendomi
  chessò "let mergewith1234 = curried_merge [1;2;3;4];;", però non sono sicuro che questo sia il 
  modo in cui l'esercizio era inteso essere svolto. *)
