let rec member a = function h::t -> if a=h then true else member a t 
                           | _ -> false;;
let member a = let rec aux = function h::t -> if a=h then true else aux t | _ -> false in aux;;
