let member a = let rec aux = function h::t -> if a=h then true else aux t | _ -> false in aux;;

let insert el ls = if member el ls then ls else ls@[el];;
