let rec prod = function h::t -> h*prod t | _ -> 1;;
prod [2;3;4];;