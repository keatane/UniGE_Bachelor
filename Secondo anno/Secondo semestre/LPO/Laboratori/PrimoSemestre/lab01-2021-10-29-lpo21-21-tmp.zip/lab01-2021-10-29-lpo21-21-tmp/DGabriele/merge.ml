let rec merge = function a::b,c::d -> if a < c then a::merge(b,c::d) else if a > c then c::merge(a::b,d) else a::merge(b,d) |
			[],c::d -> c::merge([],d) |
			a::b,[] -> a::merge(b,[]) |
			_ -> [];;	(*in questo caso _ = [],[] *)
     
(*Nota, avrei voluto inserire questa parte nei commenti, 
ma github non li rende visibili a meno che tu non li vada a cercare specificatamente, quindi:
Ho usato l'algoritmo della merge di mergesort, mi sembrava il più efficiente ed è abbastanza leggibile, opinioni?*)

(* Kevin: hai realizzato ciò in cui ho provato ma fallito :D. Non posso essere che d'accordo con l'implementazione, in quanto fedele al progetto che mi ero prefissato.
Mentre tu hai utilizzato una sola funziona, la mia idea era riutilizzare la insert e dunque usare una delle due liste come destinazione finale e inserire ordinatamente; 
nel tuo caso osservo invece che ritorni una lista ibrida *) 
