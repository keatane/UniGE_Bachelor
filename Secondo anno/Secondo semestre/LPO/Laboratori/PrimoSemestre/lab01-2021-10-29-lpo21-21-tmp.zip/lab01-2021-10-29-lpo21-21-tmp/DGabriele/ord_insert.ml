let ord_insert el = 
	let rec aux = function h::t -> if el = h then h::t else if el < h then el::h::t else h::aux t 
                        | _ -> el::[] in aux;;
