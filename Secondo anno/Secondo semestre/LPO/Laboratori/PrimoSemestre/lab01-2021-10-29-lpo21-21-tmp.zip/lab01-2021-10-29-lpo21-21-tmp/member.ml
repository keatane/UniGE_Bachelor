let rec member el = function list-> match list with
h::t -> if (h=el) then true else member el t;
|_->false ;;