let rec member el = function list-> match list with
h::t -> if (h=el) then true else member el t;
|_->false ;;

member 3 [2;3;4]=true
member 5 [2;3;4]=false
