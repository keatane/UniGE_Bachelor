let init n f = let rec aux acc = if(acc < n) then f(acc)::aux(acc+1) else [] in if (n < 0) then raise (Invalid_argument "init") else aux 0;;

init 0 (fun x->x);;
init 5 (fun x->x);;
init 5 ((+) 1);; (* (+) 1 equivale a fun x -> 1+x *)
init 10 (fun x->x*x);;
