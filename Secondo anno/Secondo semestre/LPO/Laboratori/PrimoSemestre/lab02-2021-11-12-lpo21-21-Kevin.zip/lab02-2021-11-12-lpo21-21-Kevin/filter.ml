
let filter p = 
  let rec aux acc = function h::t -> if(p h) then aux (acc@[h]) t else aux acc t | _ -> acc in aux [];; 


  
let filter p = List.fold_left (fun  acc h -> if(p h) then acc@[h] else acc) [];;

filter ((< ) 0) [-1;1;2;-2];; (* (<) 0 equivale a fun x -> 0<x *)

