
let cat l = 
  let rec aux acc = function h::t -> h^(aux acc t) | _ -> acc in aux "" l;; 

(* qui acc rimane vuoto, non sto effettivamente 'usando' acc, lo ritorno vuoto, perchè concateno gli elementi della lista stessa *)
(* l è omettibile, il pattern matching di aux si va a prendere da solo la lista *)

(* la versione alternativa che usa acc è chiamare la ricorsione passando acc^h
   
let cat l = 
  let rec aux acc = function h::t -> aux (acc^h) t | _ -> acc in aux "" l;;
   
*)

let cat = List.fold_left (^) "";;

(* List.fold_left prende da solo l'ultimo parametro: la lista passata con cat *)
(* versione 'esplicita':
   let cat l = List.fold_left (^) "" l;;
*)

cat ["This";" is ";"awesome!"];;

