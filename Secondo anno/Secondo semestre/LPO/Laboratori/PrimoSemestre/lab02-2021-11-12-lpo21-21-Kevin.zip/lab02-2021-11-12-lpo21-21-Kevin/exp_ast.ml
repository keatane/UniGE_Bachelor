type 'a list_exp_ast =  Empty | Single of 'a | Concat of 'a list_exp_ast * 'a list_exp_ast ;; 

let rec eval = function 
    Empty -> []
  | Single exp -> exp::[] (* equal to [exp] *)
  | Concat (exp1,exp2) -> eval exp1 @ eval exp2;;

eval (Concat (Single 1,Concat(Empty,Single 2)));;

eval (Concat (Single "a",Concat(Empty,Single "b")));;
