let min_el = let rec aux x = function h::t -> aux (Stdlib.min x h) t | _ -> x
  in function h::t -> Some(aux h t) | _ -> None;; 

(* come primo elemento minimo prendo la testa della lista *)

min_el [];;
min_el [3;4;6;-1];;
min_el ["orange";"apple";"banana"];;
