let combine a b = let rec aux acc l1 l2 = function h1::t1, h2::t2 -> aux (acc@[(h1, h2)]) t1 t2 
                                                 | [],[] -> acc 
                                                 | _ -> raise (Invalid_argument "combine") (* una delle due liste si è svuotata prima, ovvero le due liste erano di dimensioni diverse *)
  in aux [] a b;;

combine [] [];;
combine [1;2;3] ["a";"b";"c"];;
combine [1;2] ["a";"b";"c"];;
