type direction = North | East | South | West;;

let versor = function North -> (0,1) | East -> (1,0) | South -> (0,-1) | West -> (-1,0);; 


  versor North;;
  versor East;;
  versor South;;
  versor West;;


type action = Turn of direction | Step of int;;  

let add (a,b) (c,d) = (a+c,b+d);;

let scalar c (a,b) = (a*c,b*c);;

let move (a,(b,c)) = function Turn d -> (d,(b,c)) | Step k -> (a,add(b,c) (scalar k (versor(a))));;

  move (North,(0,0)) (Turn South);;
  move (North,(0,0)) (Step 2);;
  move (North,(0,0)) (Step (-1));;
  move (North,(0,0)) (Step 0);;

let rec do_all ((a,(b,c)) as tupla) = function h::t -> do_all (move tupla h) t | _ -> tupla;;

do_all (North,(0,0)) [Step 2;Turn East; Step 2; Step (-1);Turn South; Step 3; Step 0];;
