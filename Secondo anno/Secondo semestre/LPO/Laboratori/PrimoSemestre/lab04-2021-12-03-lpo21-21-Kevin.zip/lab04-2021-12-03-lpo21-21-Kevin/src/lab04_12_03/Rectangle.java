package lab04_12_03;

/*
 * Implementa rettangoli con lati paralleli agli assi
 */
public class Rectangle implements Shape {
	/* invariant width > 0 && height > 0 */
	public static final double defaultSize = 1;
	private double width = Rectangle.defaultSize;
	private double height = Rectangle.defaultSize;

	private final Point center = new Point();

	/*
	 * Rettangolo con centro sull'origine degli assi
	 */
	private Rectangle(double width, double height) {
	    // completare
		if(width <= 0 || height <= 0){
			System.out.println("Width or Height cannot be negative or zero");
			throw new IllegalArgumentException();
		}
		this.width = width;
		this.height = height;
	}

	private Rectangle(double width, double height, Point center) {
	    // completare
		if(width <= 0 || height <= 0){
                        System.out.println("Width or Height cannot be negative or zero");
                        throw new IllegalArgumentException();
		}
                this.width = width;
                this.height = height;
		this.center.move(center.getX(), center.getY());
	}

	/*
	 * Rettangolo con dimensioni di default e centro sull'origine degli assi
	 */
	public Rectangle() {
	}

	/*
	 * Factory method
	 */
	public static Rectangle ofWidthHeight(double width, double height) {
	    // completare
	    Rectangle rect = new Rectangle(width, height);
	    return rect;
	}

	/*
	 * Factory method
	 */
	public static Rectangle ofWidthHeightCenter(double width, double height, Point center) {
	    // completare
	    Rectangle rect = new Rectangle(width, height, center);
	    return rect;
	}

	public void move(double dx, double dy) {
	    // completare
	    this.center.move(dx, dy);
	}

	public void scale(double factor) {
	    // completare
	    // fisso il centro
	    this.width *= factor;
	    this.height *= factor;
	}

	public Point getCenter() {
	    // completare
	   	Point c = new Point(this.center.getX(), this.center.getY());
		return c;
	}

	public double perimeter() {
	    // completare
	    return width*2+height*2;
	}

	public double area() {
	    // completare
	    return width*height;
	}
}
