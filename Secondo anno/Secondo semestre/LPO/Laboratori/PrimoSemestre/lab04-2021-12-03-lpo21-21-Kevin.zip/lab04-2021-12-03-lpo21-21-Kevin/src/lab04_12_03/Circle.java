package lab04_12_03;

public class Circle implements Shape {
	/* invariant radius > 0 */
	public static final double defaultSize = 1;
	private double radius = Circle.defaultSize;
	private final Point center = new Point();

	/*
	 * Cerchio con centro sull'origine degli assi
	 */    
	private Circle(double radius) {
	    // completare
	    if(radius <= 0){
		    System.out.println("Radius cannot be negative or zero");
		    throw new IllegalArgumentException();
		}
		this.radius = radius;
		// center inizializzato di default a zero
	}

	private Circle(double radius, Point center) {
	    // completare
	     if(radius <= 0){
                    System.out.println("Radius cannot be negative or zero");
                    throw new IllegalArgumentException();
                }
		this.radius = radius;
		this.center.move(center.getX(), center.getY());
	}
    
	/*
	 * Cerchio con dimensioni di default e centro sull'origine degli assi
	 */
	public Circle() {
	}

	/*
	 * Factory method
	 */
	public static Circle ofRadius(double radius) {
	    // completare
		Circle c = new Circle(radius);
		// i campi di center sono inizializzati a zero di default
		return c;
	}

	/*
	 * Factory method
	 */
	public static Circle ofRadiusCenter(double radius, Point center) {
	    // completare
		Circle c = new Circle(radius, center);
		return c;
	}
	
	public void move(double dx, double dy) {
	    // completare
		this.center.move(dx, dy);
	}

	public void scale(double factor) {		
	    // completare
		// Fisso il centro, scalo il raggio
		this.radius *= factor;
	}

	public Point getCenter() {
	    // completare
		Point c = new Point(this.center.getX(), this.center.getY());
		return c;
	}

	public double perimeter() {
	    // completare
	    return 2*Math.PI*radius;
	}

	public double area() {
	    // completare
	    return radius*radius*Math.PI;
	}
}
