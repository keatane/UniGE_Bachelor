package lab09_04_22.parser.ast;

public class And extends BinaryOp {
	public And(Exp left, Exp right) {
		super(left, right);
	}
}
