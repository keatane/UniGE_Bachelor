package lab09_04_22.parser.ast;

public class Sign extends UnaryOp {

	public Sign(Exp exp) {
		super(exp);
	}
}
