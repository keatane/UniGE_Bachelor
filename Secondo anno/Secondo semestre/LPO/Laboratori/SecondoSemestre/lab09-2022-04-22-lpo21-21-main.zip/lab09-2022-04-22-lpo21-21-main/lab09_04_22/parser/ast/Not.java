package lab09_04_22.parser.ast;

public class Not extends UnaryOp {
	public Not(Exp exp) {
		super(exp);
	}
}
