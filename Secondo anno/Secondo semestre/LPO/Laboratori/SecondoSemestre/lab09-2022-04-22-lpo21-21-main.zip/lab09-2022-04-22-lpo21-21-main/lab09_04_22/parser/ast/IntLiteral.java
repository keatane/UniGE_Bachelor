package lab09_04_22.parser.ast;

public class IntLiteral extends SimpleLiteral<Integer> {

	public IntLiteral(int n) {
		super(n);
	}
}
