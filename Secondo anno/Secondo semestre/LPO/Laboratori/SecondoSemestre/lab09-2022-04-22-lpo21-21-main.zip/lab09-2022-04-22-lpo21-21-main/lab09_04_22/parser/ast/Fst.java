package lab09_04_22.parser.ast;

public class Fst extends UnaryOp {

    // completare
    public Fst(Exp exp) {
		super(exp);
	}
}
