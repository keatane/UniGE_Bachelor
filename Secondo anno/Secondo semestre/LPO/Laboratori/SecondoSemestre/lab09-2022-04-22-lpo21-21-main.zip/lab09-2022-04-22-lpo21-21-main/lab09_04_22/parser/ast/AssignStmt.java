package lab09_04_22.parser.ast;

public class AssignStmt extends AbstractAssignStmt {

    // completare
    public AssignStmt(Variable left, Exp right) {
		super(left, right);
	}
    
}
