package lab09_04_22.parser.ast;

public interface StmtSeq extends AST {
}
