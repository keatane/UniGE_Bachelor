package lab09_04_22.parser.ast;

public class Add extends BinaryOp {

    // completare
    public Add(Exp left, Exp right) {
		super(left, right);
	}
}
