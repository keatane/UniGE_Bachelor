package lab09_04_22.parser.ast;

public interface Variable extends Exp {
	String getName();
}
