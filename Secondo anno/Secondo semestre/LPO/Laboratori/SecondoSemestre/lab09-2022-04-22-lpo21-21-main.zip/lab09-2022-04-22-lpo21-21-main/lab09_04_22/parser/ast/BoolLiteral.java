package lab09_04_22.parser.ast;

public class BoolLiteral extends SimpleLiteral<Boolean> {

	public BoolLiteral(boolean b) {
		super(b);
	}
}
