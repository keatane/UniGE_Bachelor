package lab09_04_22.parser.ast;

public class Snd extends UnaryOp {

	public Snd(Exp exp) {
		super(exp);
	}
}
