package lab09_04_22.parser.ast;

public class VarStmt extends AbstractAssignStmt {

    // completare
    public VarStmt(Variable left, Exp right) {
		super(left, right);
	}
    
}
