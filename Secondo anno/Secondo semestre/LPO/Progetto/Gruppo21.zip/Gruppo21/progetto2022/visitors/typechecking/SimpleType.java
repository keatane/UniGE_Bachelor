package progetto2022.visitors.typechecking;

public enum SimpleType implements Type {
	BOOL, INT, ARRAY;
}
