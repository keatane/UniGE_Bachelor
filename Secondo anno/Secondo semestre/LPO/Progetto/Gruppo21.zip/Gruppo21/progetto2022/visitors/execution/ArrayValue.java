package progetto2022.visitors.execution;

import static java.util.Objects.requireNonNull;
import static java.util.Objects.hash;

import java.util.LinkedList;

public class ArrayValue extends LinkedList<Value> implements Value {
    
    public Value[] values = null;

    public ArrayValue(Value last) {
          super();
          this.addLast(requireNonNull(last));
    }

    public ArrayValue toArrayValue() {
        return this;
    }

    public Value[] toArray() {
        if(values == null) {
            values = new Value[this.size()];
            toArray(values);
        }
        return values;  
        //l'array è immutabile, una volta inizializzato values non può più
        //cambiare
    }

    @Override
	public String toString() {
        if(values == null) this.toArray();

        StringBuilder sb = new StringBuilder("[");
        for(Value v : values) {
            sb.append(v.toString() + ",");
        }
        sb.replace(sb.length()-1, sb.length(), "]");
        return sb.toString();
	}

	@Override
	public int hashCode() {
		return java.util.Arrays.hashCode(values);
	}

	@Override
	public final boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj instanceof ArrayValue av)
			return java.util.Arrays.equals(values, av.toArray());
		return false;
	}
}
