package progetto2022.parser.ast;

public interface Stmt extends AST {
}
