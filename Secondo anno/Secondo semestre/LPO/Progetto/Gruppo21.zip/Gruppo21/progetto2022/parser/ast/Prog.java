package progetto2022.parser.ast;

public interface Prog extends AST {
}
