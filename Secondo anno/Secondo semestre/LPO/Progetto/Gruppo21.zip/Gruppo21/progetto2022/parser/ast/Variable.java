package progetto2022.parser.ast;

public interface Variable extends Exp {
	String getName();
}
