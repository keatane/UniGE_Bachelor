package progetto2022.parser.ast;

public interface ExpSeq extends Exp {
    
}
