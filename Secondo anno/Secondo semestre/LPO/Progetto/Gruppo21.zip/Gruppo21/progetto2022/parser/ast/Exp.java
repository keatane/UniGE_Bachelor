package progetto2022.parser.ast;

public interface Exp extends AST {
}
