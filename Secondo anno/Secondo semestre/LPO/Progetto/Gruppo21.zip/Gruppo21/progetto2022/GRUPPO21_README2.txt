Membri Gruppo 21:
Gabriele Dellepere; 
Kevin Cattaneo; 
Roberto Lazzarini; 
Denisa Adriana Hariuc


Nota: per compilare il progetto, il nome della cartella deve essere progetto2022 e non il nome assegnato da Github!